# iztro 库 API 使用指南

## 安装

```bash
npm install iztro lunar-typescript
```

## 核心 API

### astro.astrolabeBySolarDate() — 阳历排盘

```javascript
const { astro } = require('iztro');

// 正确签名
const astrolabe = astro.astrolabeBySolarDate(
  solarDate,    // string: 'YYYY-MM-DD' 或 'YYYY-M-D'
  timeIndex,    // number: 0-11（时辰索引，不是小时数！）
  gender,       // string: '男' 或 '女'
  fixLeap,      // boolean: 是否修正闰月（阳历排盘固定true）
  language      // string: 'zh-CN'
);

// 注意：旧版 iztro 使用 astro.bySolar()，新版改为 astro.astrolabeBySolarDate()
```

### 时辰索引对照表

| 时辰 | 时间范围 | timeIndex |
|------|----------|-----------|
| 子时 | 23:00-01:00 | 0 |
| 丑时 | 01:00-03:00 | 1 |
| 寅时 | 03:00-05:00 | 2 |
| 卯时 | 05:00-07:00 | 3 |
| 辰时 | 07:00-09:00 | 4 |
| 巳时 | 09:00-11:00 | 5 |
| 午时 | 11:00-13:00 | 6 |
| 未时 | 13:00-15:00 | 7 |
| 申时 | 15:00-17:00 | 8 |
| 酉时 | 17:00-19:00 | 9 |
| 戌时 | 19:00-21:00 | 10 |
| 亥时 | 21:00-23:00 | 11 |

### 返回数据结构

```javascript
const a = astro.astrolabeBySolarDate('2026-10-28', 5, '女', true, 'zh-CN');

// 命盘信息
a.solarDate     // '2026-10-28'
a.lunarDate     // 农历日期
a.chineseDate   // 八字四柱
a.time          // '巳时'
a.timeRange     // '09:00-11:00'
a.sign          // 星座
a.zodiac        // 生肖
a.fiveElementsClass  // 五行局

// 十二宫（数组，顺序固定）
a.palaces       // [{name, heavenlyStem, earthlyBranch, majorStars, minorStars, otherStars, brightness, changsheng12, decadal, ...}]

// 宫位名称：命宫、兄弟、夫妻、子女、财帛、疾厄、迁移、仆役、官禄、田宅、福德、父母
```

### 宫位数据结构

```javascript
const ming = a.palaces.find(p => p.name === '命宫');

ming.heavenlyStem     // 天干
ming.earthlyBranch    // 地支
ming.majorStars       // [{name, brightness, mutagen, type, ...}]  主星
ming.minorStars       // [{name, brightness, mutagen, type, ...}]  辅星/煞星
ming.otherStars       // 其他杂曜
ming.changsheng12     // 长生十二神：长生、沐浴、冠带、临官、帝旺、衰、病、死、墓、绝、胎、养
ming.decadal          // 大运信息（含年龄范围等）
```

### 星曜属性

```javascript
const star = ming.majorStars[0];
star.name             // '紫微'
star.brightness       // '庙'|'旺'|'得'|'得地'|'平'|'陷'|'闲'
star.mutagen          // '禄'|'权'|'科'|'忌'|'' (空字符串表示无四化)
star.type             // 星曜类型
```

### horoscope() — 流年/大运

```javascript
const h = a.horoscope();
// h.decadal — 当前大运信息
// 注意：iztro的horoscope()默认返回出生时刻的流运信息
// 要获取不同年龄的大运，需手动推算（见下文"大运推算"）
```

## 已知 Bug 与修复

### Bug 1: bySolar 第二参数误传（严重）

**错误写法**（会导致所有命盘时柱为子时）：
```javascript
// ❌ 错误：第二个参数传了0（子时），第三个参数传了true（非合法性别）
const a = astro.astrolabeBySolarDate(dateStr, 0, true, 'zh-CN');
```

**正确写法**：
```javascript
// ✅ 正确：第二个参数是时辰索引(0-11)，第三个参数是性别字符串
const a = astro.astrolabeBySolarDate(dateStr, timeIndex, '女', true, 'zh-CN');
```

### Bug 2: lunar-typescript Solar 对象无 getTime()

**错误**：
```javascript
const solar = Solar.fromDate(new Date());
solar.getTime();  // ❌ TypeError: solar.getTime is not a function
```

**修复**：使用原生 Date 迭代，不依赖 Solar 对象的时间方法：
```javascript
for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
  const solar = Solar.fromYmd(d.getFullYear(), d.getMonth()+1, d.getDate());
  // ...
}
```

### Bug 3: 五鼠遁时柱推算丁壬/戊癸混淆

**错误规则**（丁壬和戊癸搞反）：
```javascript
// ❌ 错误
'丁':['壬','癸','甲','乙','丙','丁','戊','己','庚','辛','壬','癸'],
'壬':['壬','癸','甲','乙','丙','丁','戊','己','庚','辛','壬','癸'],
'戊':['甲','乙','丙','丁','戊','己','庚','辛','壬','癸','甲','乙'],
'癸':['甲','乙','丙','丁','戊','己','庚','辛','壬','癸','甲','乙'],
```

**正确规则**：
```javascript
// ✅ 正确：甲己还加甲，乙庚丙作初，丙辛从戊起，丁壬庚子居，戊癸何方发，壬子是真途
'甲':['甲','乙','丙','丁','戊','己','庚','辛','壬','癸','甲','乙'],
'己':['甲','乙','丙','丁','戊','己','庚','辛','壬','癸','甲','乙'],
'乙':['丙','丁','戊','己','庚','辛','壬','癸','甲','乙','丙','丁'],
'庚':['丙','丁','戊','己','庚','辛','壬','癸','甲','乙','丙','丁'],
'丙':['戊','己','庚','辛','壬','癸','甲','乙','丙','丁','戊','己'],
'辛':['戊','己','庚','辛','壬','癸','甲','乙','丙','丁','戊','己'],
'丁':['庚','辛','壬','癸','甲','乙','丙','丁','戊','己','庚','辛'],
'壬':['庚','辛','壬','癸','甲','乙','丙','丁','戊','己','庚','辛'],
'戊':['壬','癸','甲','乙','丙','丁','戊','己','庚','辛','壬','癸'],
'癸':['壬','癸','甲','乙','丙','丁','戊','己','庚','辛','壬','癸'],
```

### 时柱验证方法

用 lunar-typescript 交叉验证时柱是否正确：
```javascript
const { Solar } = require('lunar-typescript');
// 卯时=6点, 辰时=8点, 巳时=10点, ...
const BRANCH_HOURS = { '子':0,'丑':2,'寅':4,'卯':6,'辰':8,'巳':10,'午':12,'未':14,'申':16,'酉':18,'戌':20,'亥':22 };
const solar = Solar.fromYmdHms(year, month, day, BRANCH_HOURS[hourBranch], 0, 0);
const hourPillar = solar.getLunar().getTimeInGanZhi();
// 与五鼠遁计算结果比对
```

## 大运推算（手动）

iztro 的 `horoscope()` 方法对不同年龄的大运支持不完善，建议手动推算：

### 规则
- **女命阳年**（如丙午年）：从命宫**逆排**
- **女命阴年**：从命宫**顺排**
- **男命阳年**：从命宫**顺排**
- **男命阴年**：从命宫**逆排**

### 推算方法

```javascript
// 1. 找到命宫在palaces数组中的索引
const mingIdx = a.palaces.findIndex(p => p.name === '命宫');

// 2. 确定方向：女命阳年逆排（index递减）
const isFemale = gender === '女';
const yearStem = yearPillar[0];
const isYangYear = '甲丙戊庚壬'.includes(yearStem);
const reverse = (isFemale && isYangYear) || (!isFemale && !isYangYear);

// 3. 计算起运年龄（简化：阳年女命约2岁起运）
const startAge = 2; // 实际应根据出生日到节气天数计算

// 4. 逆排大运宫位
for (let i = 0; i < 8; i++) {
  const ageStart = startAge + i * 10;
  const ageEnd = ageStart + 9;
  const palaceIdx = reverse 
    ? (mingIdx - i + 12) % 12  // 逆排
    : (mingIdx + i) % 12;       // 顺排
  const dayunPalace = a.palaces[palaceIdx];
  // 读取该宫位的主星、吉星、煞星
}
```

## 常用星曜分类

### 主星（14颗）
紫微、天机、太阳、武曲、天同、廉贞、天府、贪狼、巨门、太阴、天相、天梁、七杀、破军

### 吉星（辅弼魁钺+文昌文曲+禄存天马）
左辅、右弼、天魁、天钺、文昌、文曲、禄存、天马

### 煞星（六煞）
擎羊、陀罗、火星、铃星、地空、地劫

### 亮度等级（从吉到凶）
庙 > 旺 > 得 > 得地 > 平 > 闲 > 陷

### 四化
- 化禄：财禄、福气
- 化权：权力、进取
- 化科：名声、学业
- 化忌：阻碍、专注（落有利宫位为吉）

### 长生十二神（从吉到凶）
长生 > 沐浴 > 冠带 > 临官 > 帝旺 > 衰 > 病 > 死 > 墓 > 绝 > 胎 > 养

吉位：长生、帝旺、临官、冠带
凶位：死、墓、绝
