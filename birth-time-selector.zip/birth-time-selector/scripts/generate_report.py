# -*- coding: utf-8 -*-
"""
三体系综合择日报告生成器

用法：
  python generate_report.py <inputJson> <outputHtml> [babyGender] [focus] [city]
  python generate_report.py search-triple.json 择日吉辰报告.html 女 学业文昌,财运事业,健康平安 北京
"""
import json
import os
import sys
from datetime import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def get_practicality(weekday, hour_branch):
    """评估手术实用性"""
    score = 0
    notes = []
    # 工作日 vs 周末
    if weekday in ['一', '二', '三', '四', '五']:
        score += 2
        notes.append('工作日')
    else:
        notes.append('周末（需确认排班）')
    # 时段
    hour_ranges = {
        '辰': '上午', '巳': '上午', '午': '中午', '未': '下午',
        '申': '下午', '酉': '傍晚', '戌': '晚间', '亥': '夜间',
        '子': '深夜', '丑': '凌晨', '寅': '凌晨', '卯': '清晨'
    }
    period = hour_ranges.get(hour_branch, '')
    if period in ['上午', '下午']:
        score += 2
        notes.append(f'{period}（最佳）')
    elif period in ['中午']:
        score += 1
        notes.append(f'{period}')
    elif period in ['晚间', '夜间', '深夜', '凌晨', '清晨', '傍晚']:
        score -= 1
        notes.append(f'{period}（需特殊安排）')
    stars = '★★★' if score >= 4 else '★★' if score >= 2 else '★' if score >= 0 else '△'
    return stars, '、'.join(notes)


def generate_html(results, baby_gender='女', focus='学业文昌,财运事业,健康平安', city='北京'):
    top6 = results[:6]

    # 构建对比表行
    table_rows = []
    for i, r in enumerate(top6):
        w = r.get('western', {})
        practicality, prac_note = get_practicality(r.get('weekday', ''), r.get('hourBranch', ''))
        lz_info = f"{r['lzPalace']}[{r['lzBright']}]" if r.get('lzMutagen') == '忌' else '无'
        sun_info = f"{r.get('tyPalace','')}[{r.get('tyBright','')}]"
        moon_info = f"{r.get('tyiPalace','')}[{r.get('tyiBright','')}]"
        table_rows.append(f"""
        <tr>
          <td class="rank">{i+1}</td>
          <td><strong>{r['date']}</strong><br><span class="muted">{r['hourBranch']}时 {r['timeRange']}</span></td>
          <td><strong>{r['triple_score']}</strong><br><span class="muted">八{r.get('bazi_norm','')} 紫{r.get('ziwei_norm','')} 西{r.get('western_norm','')}</span></td>
          <td>{r.get('mingMain','')}<br><span class="muted">{r.get('mingLucky','') and '★'+r.get('mingLucky','') or ''} [{r.get('changsheng','')}]</span></td>
          <td>{r.get('fudeMain','')}</td>
          <td>{lz_info}</td>
          <td>{sun_info}<br>{moon_info}</td>
          <td>{w.get('sun_sign','')}[{w.get('sun_dignity','')}]<br>{w.get('moon_sign','')}[{w.get('moon_dignity','')}]</td>
          <td>{practicality}<br><span class="muted">{prac_note}</span></td>
        </tr>""")

    # 构建详细分析
    details = []
    for i, r in enumerate(top6):
        w = r.get('western', {})
        practicality, prac_note = get_practicality(r.get('weekday', ''), r.get('hourBranch', ''))
        lz_info = f"{r['lzPalace']}[{r['lzBright']}]" if r.get('lzMutagen') == '忌' else '无'

        # 西方占星星体摘要
        planet_rows = []
        for p in w.get('planets', []):
            planet_rows.append(f"<tr><td>{p['name_cn']}</td><td>{p['sign']}{p['sign_symbol']}</td><td>{p['degree']:.1f}°</td><td>{p['dignity']}</td><td>第{p.get('house','-')}宫</td></tr>")

        # 西方占星评分
        ws = w.get('scores', {})
        aspects = w.get('aspect_summary', {})

        label = '首选' if i == 0 else '次选' if i == 1 else f'第{i+1}选'
        details.append(f"""
      <div class="candidate {'first' if i == 0 else ''}">
        <h3>{label}：{r['date']} {r['hourBranch']}时（{r['timeRange']}）</h3>
        <div class="scores">
          <span class="badge badge-triple">三体系 {r['triple_score']}</span>
          <span class="badge badge-bazi">八字 {r.get('baziScore','')}</span>
          <span class="badge badge-ziwei">紫微 {r.get('ziweiScore','')}</span>
          <span class="badge badge-western">西方 {w.get('western_total','')}</span>
          <span class="badge badge-prac">{practicality} {prac_note}</span>
        </div>
        <div class="grid">
          <div class="card">
            <h4>八字四柱</h4>
            <p class="bazi">{r.get('bazi','')}</p>
            <p>五行局：{r.get('fiveElements','')}</p>
          </div>
          <div class="card">
            <h4>紫微命宫</h4>
            <p>{r.get('mingMain','')} {r.get('mingLucky','') and '★'+r.get('mingLucky','') or ''}</p>
            <p>长生位：{r.get('changsheng','')} | 命分：{r.get('mingScore','')}</p>
          </div>
          <div class="card">
            <h4>福德宫</h4>
            <p>{r.get('fudeMain','')} {r.get('fudeLucky','') and '★'+r.get('fudeLucky','') or ''}</p>
            <p>福德分：{r.get('fudeScore','')}</p>
          </div>
          <div class="card">
            <h4>化忌 · 日月</h4>
            <p>化忌：{lz_info}</p>
            <p>太阳：{r.get('tyPalace','')}[{r.get('tyBright','')}] | 太阴：{r.get('tyiPalace','')}[{r.get('tyiBright','')}]</p>
          </div>
          <div class="card">
            <h4>西方占星</h4>
            <p>太阳：{w.get('sun_sign','')}[{w.get('sun_dignity','')}] | 月亮：{w.get('moon_sign','')}[{w.get('moon_dignity','')}]</p>
            <p>上升：{w.get('asc_sign','')}</p>
          </div>
          <div class="card">
            <h4>三体系评分</h4>
            <p>学业：{ws.get('study',0):+d} | 财运：{ws.get('career',0):+d} | 健康：{ws.get('health',0):+d}</p>
            <p>相位：三分{aspects.get('trine',0)} 六分{aspects.get('sextile',0)} 四分{aspects.get('square',0)} 对分{aspects.get('opp',0)}</p>
          </div>
        </div>
        {'<div class="warning">⚠ 日月均落陷</div>' if w.get('sun_moon_both_bad') else ''}
      </div>""")

    table_html = '\n'.join(table_rows)
    details_html = '\n'.join(details)
    now = datetime.now().strftime('%Y-%m-%d %H:%M')

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>择日吉辰报告 — 三体系综合分析</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ font-family: -apple-system, 'Segoe UI', 'Microsoft YaHei', sans-serif; background: #f5f5f5; color: #333; line-height: 1.6; padding: 20px; }}
  .container {{ max-width: 1000px; margin: 0 auto; background: white; border-radius: 12px; padding: 40px; box-shadow: 0 2px 12px rgba(0,0,0,0.08); }}
  h1 {{ text-align: center; color: #1a1a2e; margin-bottom: 8px; font-size: 28px; }}
  h2 {{ color: #1a1a2e; margin: 30px 0 15px; font-size: 22px; border-bottom: 2px solid #e8e8e8; padding-bottom: 8px; }}
  h3 {{ color: #16213e; margin: 20px 0 10px; font-size: 18px; }}
  h4 {{ color: #0f3460; margin-bottom: 8px; font-size: 15px; }}
  .subtitle {{ text-align: center; color: #666; margin-bottom: 30px; font-size: 14px; }}
  .info-bar {{ background: #f0f4ff; border-radius: 8px; padding: 12px 20px; margin-bottom: 25px; font-size: 14px; }}
  table {{ width: 100%; border-collapse: collapse; margin: 15px 0; font-size: 13px; }}
  th {{ background: #1a1a2e; color: white; padding: 10px 8px; text-align: center; font-weight: 500; }}
  td {{ padding: 10px 8px; text-align: center; border-bottom: 1px solid #eee; vertical-align: top; }}
  tr:hover {{ background: #f9f9ff; }}
  .rank {{ font-weight: bold; font-size: 16px; color: #e94560; }}
  .muted {{ color: #999; font-size: 12px; }}
  .candidate {{ background: #fafafa; border-radius: 10px; padding: 20px; margin: 20px 0; border: 1px solid #eee; }}
  .candidate.first {{ border-color: #e94560; border-width: 2px; background: #fff5f5; }}
  .scores {{ margin: 10px 0; }}
  .badge {{ display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: 12px; margin-right: 6px; margin-bottom: 4px; }}
  .badge-triple {{ background: #e94560; color: white; }}
  .badge-bazi {{ background: #0f3460; color: white; }}
  .badge-ziwei {{ background: #533483; color: white; }}
  .badge-western {{ background: #e67e22; color: white; }}
  .badge-prac {{ background: #27ae60; color: white; }}
  .grid {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin: 15px 0; }}
  .card {{ background: white; border: 1px solid #e0e0e0; border-radius: 8px; padding: 12px; }}
  .bazi {{ font-size: 16px; font-weight: bold; color: #1a1a2e; letter-spacing: 2px; }}
  .warning {{ background: #fff3cd; border: 1px solid #ffc107; border-radius: 6px; padding: 8px 12px; margin: 10px 0; color: #856404; font-size: 13px; }}
  .methodology {{ background: #f8f9fa; border-radius: 8px; padding: 20px; margin: 20px 0; font-size: 13px; color: #555; }}
  .methodology ul {{ margin-left: 20px; }}
  .methodology li {{ margin: 4px 0; }}
  @media (max-width: 768px) {{ .grid {{ grid-template-columns: 1fr; }} }}
</style>
</head>
<body>
<div class="container">
  <h1>择日吉辰报告</h1>
  <p class="subtitle">八字命理 · 紫微斗数 · 西方占星 三体系综合分析</p>
  <div class="info-bar">
    <strong>宝宝性别：</strong>{baby_gender} ｜
    <strong>侧重：</strong>{focus} ｜
    <strong>出生地：</strong>{city}（影响上升星座）｜
    <strong>生成时间：</strong>{now}
  </div>

  <h2>一、综合排名对比</h2>
  <p class="muted">八字30% + 紫微40% + 西方30% 加权评分</p>
  <table>
    <thead>
      <tr>
        <th>排名</th><th>日期时辰</th><th>三体系分</th><th>紫微命宫</th><th>福德宫</th>
        <th>化忌位置</th><th>日月庙旺</th><th>西方日月</th><th>实用性</th>
      </tr>
    </thead>
    <tbody>
      {table_html}
    </tbody>
  </table>

  <h2>二、候选方案详解</h2>
  {details_html}

  <h2>三、评分体系说明</h2>
  <div class="methodology">
    <ul>
      <li><strong>八字评分（30%）</strong>：五行平衡、日主强弱、地支关系（六冲六害六合）、五行俱全</li>
      <li><strong>紫微评分（40%）</strong>：命宫质量（主星庙旺+吉星+长生位）×1.5 + 福德宫质量 ×1.2 + 官禄宫 + 财帛宫 + 日月庙旺 + 化忌位置（田宅/官禄/福德/父母为吉）+ 大运走势</li>
      <li><strong>西方占星（30%）</strong>：水星庙旺+宫位（学业）、木星金星庙旺+太阳木星10宫（财运事业）、太阳月亮庙旺+日月相位（健康）、行星相位综合（性格）</li>
      <li><strong>化忌有利宫位</strong>：田宅（锁忌积财）、官禄（专注事业）、福德（精神专注）、父母（长辈庇荫）</li>
      <li><strong>大运推算</strong>：女命阳年逆排、男命阳年顺排，从命宫起每10年一步</li>
      <li><strong>时柱推算</strong>：五鼠遁（甲己还加甲，乙庚丙作初，丙辛从戊起，丁壬庚子居，戊癸何方发，壬子是真途）</li>
    </ul>
  </div>

  <p class="muted" style="text-align:center; margin-top:30px;">
    本报告综合三套命理体系仅供参考，具体手术时间请遵医嘱并结合医院排班实际情况。
  </p>
</div>
</body>
</html>"""


def main():
    if len(sys.argv) < 3:
        print("用法: python generate_report.py <inputJson> <outputHtml> [babyGender] [focus] [city]")
        print("示例: python generate_report.py search-triple.json 择日吉辰报告.html 女 学业文昌,财运事业,健康平安 北京")
        sys.exit(1)

    input_path = sys.argv[1]
    output_path = sys.argv[2]
    baby_gender = sys.argv[3] if len(sys.argv) > 3 else '女'
    focus = sys.argv[4] if len(sys.argv) > 4 else '学业文昌,财运事业,健康平安'
    city = sys.argv[5] if len(sys.argv) > 5 else '北京'

    with open(input_path, 'r', encoding='utf-8') as f:
        results = json.load(f)

    html = generate_html(results, baby_gender, focus, city)

    # 确保输出目录存在
    out_dir = os.path.dirname(output_path)
    if out_dir and not os.path.exists(out_dir):
        os.makedirs(out_dir)

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)

    print(f"报告已生成：{output_path}")
    print(f"包含 {min(len(results), 6)} 个候选方案的详细分析")


if __name__ == '__main__':
    main()
