#!/usr/bin/env node
/**
 * 单个时辰详细紫微排盘 + 大运推算
 *
 * 用法：
 *   node detail-ziwei.js <date> <timeIndex> <gender>
 *   node detail-ziwei.js 2026-10-28 5 女
 *
 * 输出：完整十二宫星曜 + 八步大运走势
 */
const { astro } = require('iztro');
const { Solar } = require('lunar-typescript');

const BRANCHES = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
const MAIN_STARS = ['紫微','天机','太阳','武曲','天同','廉贞','天府','贪狼','巨门','太阴','天相','天梁','七杀','破军'];
const LUCKY_STARS = ['左辅','右弼','天魁','天钺','文昌','文曲','禄存','天马'];
const UNLUCKY_STARS = ['擎羊','陀罗','火星','铃星','地空','地劫'];
const PALACE_NAMES = ['命宫','兄弟','夫妻','子女','财帛','疾厄','迁移','仆役','官禄','田宅','福德','父母'];

function getHourStem(dayStem, hourBranch) {
  const rules = {
    '甲':['甲','乙','丙','丁','戊','己','庚','辛','壬','癸','甲','乙'],
    '己':['甲','乙','丙','丁','戊','己','庚','辛','壬','癸','甲','乙'],
    '乙':['丙','丁','戊','己','庚','辛','壬','癸','甲','乙','丙','丁'],
    '庚':['丙','丁','戊','己','庚','辛','壬','癸','甲','乙','丙','丁'],
    '丙':['戊','己','庚','辛','壬','癸','甲','乙','丙','丁','戊','己'],
    '辛':['戊','己','庚','辛','壬','癸','甲','乙','丙','丁','戊','己'],
    '丁':['庚','辛','壬','癸','甲','乙','丙','丁','戊','己','庚','辛'],
    '壬':['庚','辛','壬','癸','甲','乙','丙','丁','戊','己','庚','辛'],
    '戊':['壬','癸','甲','乙','丙','丁','戊','己','庚','辛','壬','癸'],
    '癸':['壬','癸','甲','乙','丙','丁','戊','己','庚','辛','壬','癸'],
  };
  return rules[dayStem][BRANCHES.indexOf(hourBranch)];
}

function formatStars(palace) {
  if (!palace) return '无';
  const main = (palace.majorStars || []).filter(s => s.name && MAIN_STARS.includes(s.name))
    .map(s => `${s.name}[${s.brightness || ''}]${s.mutagen ? '化' + s.mutagen : ''}`);
  const lucky = (palace.minorStars || []).filter(s => s.name && LUCKY_STARS.includes(s.name))
    .map(s => s.name);
  const unlucky = (palace.minorStars || []).filter(s => s.name && UNLUCKY_STARS.includes(s.name))
    .map(s => s.name);
  const other = (palace.otherStars || []).filter(s => s.name).map(s => s.name).slice(0, 3);
  const cs = palace.changsheng12 || '';
  let result = main.join('·') || '空宫';
  if (lucky.length) result += ' ★' + lucky.join(',');
  if (unlucky.length) result += ' △' + unlucky.join(',');
  if (other.length) result += ' +' + other.join(',');
  if (cs) result += ` [${cs}]`;
  return result;
}

function rateDaYun(palace) {
  if (!palace) return '—';
  let stars = [];
  const main = (palace.majorStars || []).filter(s => s.name && MAIN_STARS.includes(s.name));
  const lucky = (palace.minorStars || []).filter(s => s.name && LUCKY_STARS.includes(s.name));
  const unlucky = (palace.minorStars || []).filter(s => s.name && UNLUCKY_STARS.includes(s.name));
  let score = 0;
  for (const s of main) {
    if (['庙','旺','得','得地'].includes(s.brightness)) { score += 2; stars.push(s.name + '[旺]'); }
    else if (['陷','闲'].includes(s.brightness)) { score -= 1; stars.push(s.name + '[陷]'); }
    else stars.push(s.name);
    if (s.mutagen === '禄' || s.mutagen === '权' || s.mutagen === '科') { score += 2; stars.push('化' + s.mutagen); }
  }
  score += lucky.length * 2;
  score -= unlucky.length * 2;
  let rating = score >= 6 ? '★★★' : score >= 3 ? '★★' : score >= 0 ? '★' : '△';
  const luckyNames = lucky.map(s => s.name).join(',');
  const unluckyNames = unlucky.map(s => s.name).join(',');
  return `${rating} ${stars.join('·')}${luckyNames ? ' ★' + luckyNames : ''}${unluckyNames ? ' △' + unluckyNames : ''}`;
}

function main() {
  const args = process.argv.slice(2);
  if (args.length < 3) {
    console.log('用法: node detail-ziwei.js <date> <timeIndex> <gender>');
    console.log('示例: node detail-ziwei.js 2026-10-28 5 女');
    console.log('timeIndex: 子=0 丑=1 寅=2 卯=3 辰=4 巳=5 午=6 未=7 申=8 酉=9 戌=10 亥=11');
    process.exit(1);
  }

  const [dateStr, tiStr, gender] = args;
  const timeIndex = parseInt(tiStr);
  const hourBranch = BRANCHES[timeIndex];

  // 八字
  const [y, m, d] = dateStr.split('-').map(Number);
  const solar = Solar.fromYmd(y, m, d);
  const lunar = solar.getLunar();
  const yP = lunar.getYearInGanZhiExact();
  const mP = lunar.getMonthInGanZhiExact();
  const dP = lunar.getDayInGanZhiExact();
  const hStem = getHourStem(dP[0], hourBranch);
  const hP = hStem + hourBranch;

  // 时柱验证
  const BRANCH_TO_HOUR = {0:0, 1:2, 2:4, 3:6, 4:8, 5:10, 6:12, 7:14, 8:16, 9:18, 10:20, 11:22};
  const verifyHour = BRANCH_TO_HOUR[timeIndex];
  const verifySolar = Solar.fromYmdHms(y, m, d, verifyHour, 0, 0);
  const verifyHourPillar = verifySolar.getLunar().getTimeInGanZhi();
  const verifyOK = verifyHourPillar === hP;

  // 紫微排盘
  const a = astro.astrolabeBySolarDate(dateStr, timeIndex, gender, true, 'zh-CN');

  console.log(`\n${'═'.repeat(70)}`);
  console.log(`  详细紫微排盘：${dateStr} ${hourBranch}时(${timeIndex}) ${gender}`);
  console.log(`${'═'.repeat(70)}\n`);

  console.log(`阳历：${a.solarDate}`);
  console.log(`农历：${a.lunarDate}`);
  console.log(`八字：${yP} ${mP} ${dP} ${hP}`);
  console.log(`时柱验证：${verifyOK ? '✅ ' + hP + ' (与lunar-typescript一致)' : '❌ 五鼠遁=' + hP + ' lunar=' + verifyHour}`);
  console.log(`五行局：${a.fiveElementsClass}`);
  console.log(`星座：${a.sign} | 生肖：${a.zodiac}\n`);

  // 十二宫
  console.log('── 十二宫星曜 ──\n');
  for (const p of a.palaces) {
    console.log(`  ${p.name}(${p.heavenlyStem}${p.earthlyBranch}): ${formatStars(p)}`);
  }

  // 大运推算
  console.log('\n── 大运走势 ──\n');
  const mingIdx = a.palaces.findIndex(p => p.name === '命宫');
  const yearStem = yP[0];
  const isYangYear = '甲丙戊庚壬'.includes(yearStem);
  const isFemale = gender === '女';
  const reverse = (isFemale && isYangYear) || (!isFemale && !isYangYear);
  const startAge = 2; // 简化起运年龄

  console.log(`  排运方向：${reverse ? '逆排' : '顺排'}（${gender}命${isYangYear ? '阳' : '阴'}年）`);
  console.log(`  起运年龄：${startAge}岁（简化估算）\n`);

  for (let i = 0; i < 8; i++) {
    const ageStart = startAge + i * 10;
    const ageEnd = ageStart + 9;
    const palaceIdx = reverse
      ? (mingIdx - i + 12 * 10) % 12
      : (mingIdx + i) % 12;
    const dp = a.palaces[palaceIdx];
    console.log(`  ${ageStart}-${ageEnd}岁：${dp.name}(${dp.heavenlyStem}${dp.earthlyBranch}) → ${rateDaYun(dp)}`);
  }

  // 关键星曜位置汇总
  console.log('\n── 关键星曜位置 ──\n');
  for (const p of a.palaces) {
    const all = [...(p.majorStars || []), ...(p.minorStars || [])];
    for (const s of all) {
      if (['太阳', '太阴', '廉贞'].includes(s.name)) {
        console.log(`  ${s.name}[${s.brightness || ''}]${s.mutagen ? '化' + s.mutagen : ''} → ${p.name}`);
      }
    }
  }
  console.log('');
}

main();
