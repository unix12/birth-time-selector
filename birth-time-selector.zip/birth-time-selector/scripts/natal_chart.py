# -*- coding: utf-8 -*-
"""
西方占星计算 + 三体系综合排名

用法：
  python natal_chart.py <inputJson> [latitude] [longitude] [tz_offset]
  python natal_chart.py search-top.json 39.9042 116.4074 8

输入：search-top.json（由 search-full.js 生成）
输出：search-triple.json（三体系综合排名 Top 20）
"""
import ephem
import math
import json
import os
import sys
from datetime import datetime, timedelta

# ==================== 常量 ====================
ZODIAC_SIGNS = ['白羊座', '金牛座', '双子座', '巨蟹座', '狮子座', '处女座',
                '天秤座', '天蝎座', '射手座', '摩羯座', '水瓶座', '双鱼座']
ZODIAC_SYMBOLS = ['♈', '♉', '♊', '♋', '♌', '♍', '♎', '♏', '♐', '♑', '♒', '♓']
ZODIAC_ELEMENTS = ['火', '土', '风', '水', '火', '土', '风', '水', '火', '土', '风', '水']

PLANETS_CN = {
    'Sun': '太阳', 'Moon': '月亮', 'Mercury': '水星', 'Venus': '金星',
    'Mars': '火星', 'Jupiter': '木星', 'Saturn': '土星',
    'Uranus': '天王星', 'Neptune': '海王星', 'Pluto': '冥王星'
}

DIGNITY = {
    'Sun':    {'ruler': '狮子座', 'exalted': '白羊座', 'detriment': '水瓶座', 'fall': '天秤座'},
    'Moon':   {'ruler': '巨蟹座', 'exalted': '金牛座', 'detriment': '摩羯座', 'fall': '天蝎座'},
    'Mercury':{'ruler': '双子座,处女座', 'exalted': '处女座', 'detriment': '射手座,双鱼座', 'fall': '双鱼座'},
    'Venus':  {'ruler': '金牛座,天秤座', 'exalted': '双鱼座', 'detriment': '天蝎座,白羊座', 'fall': '处女座'},
    'Mars':   {'ruler': '白羊座,天蝎座', 'exalted': '摩羯座', 'detriment': '天秤座,金牛座', 'fall': '巨蟹座'},
    'Jupiter':{'ruler': '射手座,双鱼座', 'exalted': '巨蟹座', 'detriment': '双子座,处女座', 'fall': '摩羯座'},
    'Saturn': {'ruler': '摩羯座,水瓶座', 'exalted': '天秤座', 'detriment': '巨蟹座,狮子座', 'fall': '白羊座'},
    'Uranus': {'ruler': '水瓶座', 'exalted': '天蝎座', 'detriment': '狮子座', 'fall': '金牛座'},
    'Neptune':{'ruler': '双鱼座', 'exalted': '巨蟹座', 'detriment': '处女座', 'fall': '摩羯座'},
    'Pluto':  {'ruler': '天蝎座', 'exalted': '白羊座,狮子座', 'detriment': '金牛座,天秤座', 'fall': '水瓶座'},
}

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


def get_zodiac_sign(ecliptic_lon_deg):
    sign_idx = int(ecliptic_lon_deg / 30) % 12
    degree_in_sign = ecliptic_lon_deg % 30
    return sign_idx, degree_in_sign


def get_dignity(planet, sign_name):
    d = DIGNITY.get(planet, {})
    if sign_name in d.get('ruler', '').split(','):
        return '入庙', 'ruler'
    if sign_name == d.get('exalted', ''):
        return '旺相', 'exalted'
    if sign_name in d.get('detriment', '').split(','):
        return '落陷', 'detriment'
    if sign_name == d.get('fall', ''):
        return '失势', 'fall'
    return '平', 'normal'


def calc_ascendant(observer):
    lst = observer.sidereal_time()
    T = (observer.date - ephem.J2000) / 36525.0
    epsilon_deg = 23.4393 - 0.0130042 * T - 1.64e-7 * T**2 + 5.04e-7 * T**3
    epsilon = math.radians(epsilon_deg)
    lat = observer.lat
    y = -math.cos(lst)
    x = math.sin(lst) * math.cos(epsilon) + math.tan(lat) * math.sin(epsilon)
    asc_rad = math.atan2(y, x)
    if asc_rad < 0:
        asc_rad += 2 * math.pi
    return math.degrees(asc_rad)


def calc_aspects(positions):
    ASPECTS = [
        (0, '合相', '☌', 8),
        (60, '六分相', '⚹', 6),
        (90, '四分相', '☐', 6),
        (120, '三分相', '△', 8),
        (180, '对分相', '☍', 8),
    ]
    aspects = []
    planet_names = list(positions.keys())
    for i in range(len(planet_names)):
        for j in range(i + 1, len(planet_names)):
            p1, p2 = planet_names[i], planet_names[j]
            diff = abs(positions[p1] - positions[p2])
            if diff > 180:
                diff = 360 - diff
            for angle, name, symbol, orb in ASPECTS:
                if abs(diff - angle) <= orb:
                    actual_orb = abs(diff - angle)
                    if angle in [60, 120]:
                        nature = '吉'
                    elif angle in [90, 180]:
                        nature = '凶'
                    else:
                        nature = '中'
                    aspects.append({
                        'p1': p1, 'p2': p2,
                        'p1_cn': PLANETS_CN.get(p1, p1), 'p2_cn': PLANETS_CN.get(p2, p2),
                        'aspect': name, 'symbol': symbol, 'angle': angle,
                        'orb': round(actual_orb, 2), 'nature': nature,
                    })
                    break
    return aspects


def analyze_western(date_str, hour, minute, latitude, longitude, tz_offset):
    """计算西方本命星盘"""
    local_dt = datetime.strptime(date_str, '%Y-%m-%d').replace(hour=hour, minute=minute, second=0)
    utc_dt = local_dt - timedelta(hours=tz_offset)

    observer = ephem.Observer()
    observer.lat = str(latitude)
    observer.lon = str(longitude)
    observer.date = utc_dt

    planet_objects = {
        'Sun': ephem.Sun(observer), 'Moon': ephem.Moon(observer),
        'Mercury': ephem.Mercury(observer), 'Venus': ephem.Venus(observer),
        'Mars': ephem.Mars(observer), 'Jupiter': ephem.Jupiter(observer),
        'Saturn': ephem.Saturn(observer), 'Uranus': ephem.Uranus(observer),
        'Neptune': ephem.Neptune(observer), 'Pluto': ephem.Pluto(observer),
    }

    positions = {}
    planet_info = []

    for name, obj in planet_objects.items():
        ecl = ephem.Ecliptic(obj)
        lon_deg = math.degrees(ecl.lon)
        if lon_deg < 0:
            lon_deg += 360
        sign_idx, deg_in_sign = get_zodiac_sign(lon_deg)
        sign_name = ZODIAC_SIGNS[sign_idx]
        dignity, _ = get_dignity(name, sign_name)
        positions[name] = lon_deg
        planet_info.append({
            'name': name, 'name_cn': PLANETS_CN[name],
            'sign': sign_name, 'sign_symbol': ZODIAC_SYMBOLS[sign_idx],
            'degree': round(deg_in_sign, 1), 'dignity': dignity,
            'sign_idx': sign_idx, 'element': ZODIAC_ELEMENTS[sign_idx],
        })

    asc_deg = calc_ascendant(observer)
    asc_sign_idx, asc_deg_in_sign = get_zodiac_sign(asc_deg)

    # 整宫制分配宫位
    asc_sign = int(asc_deg / 30) % 12
    for p in planet_info:
        p['house'] = (p['sign_idx'] - asc_sign) % 12 + 1

    aspects = calc_aspects(positions)

    # 评分
    scores = {'study': 0, 'career': 0, 'health': 0}
    notes = {'study': [], 'career': [], 'health': []}
    pm = {p['name']: p for p in planet_info}

    # 学业
    mercury = pm.get('Mercury', {})
    m_dig = mercury.get('dignity', '')
    m_house = mercury.get('house', 0)
    if m_dig in ['入庙', '旺相']:
        scores['study'] += 25; notes['study'].append(f"水星{m_dig}(学业极佳)")
    elif m_dig in ['落陷', '失势']:
        scores['study'] -= 10; notes['study'].append(f"水星{m_dig}")
    else:
        scores['study'] += 10; notes['study'].append(f"水星于{mercury.get('sign', '')}")
    if m_house in [3, 9]:
        scores['study'] += 15; notes['study'].append(f"水星{m_house}宫(学习宫)")
    elif m_house in [1, 10, 11]:
        scores['study'] += 8
    for a in aspects:
        if {'Mercury', 'Jupiter'} == {a['p1'], a['p2']} and a['angle'] in [120, 60]:
            scores['study'] += 15; notes['study'].append(f"水星木星{a['aspect']}(智慧)")
        if {'Mercury', 'Saturn'} == {a['p1'], a['p2']} and a['angle'] in [120, 60]:
            scores['study'] += 12; notes['study'].append(f"水星土星{a['aspect']}(恒心)")

    # 财运事业
    jupiter = pm.get('Jupiter', {})
    venus = pm.get('Venus', {})
    saturn = pm.get('Saturn', {})
    sun = pm.get('Sun', {})
    if jupiter.get('dignity') in ['入庙', '旺相']:
        scores['career'] += 20; notes['career'].append(f"木星{jupiter['dignity']}(财运佳)")
    elif jupiter.get('dignity') in ['落陷', '失势']:
        scores['career'] -= 8
    else:
        scores['career'] += 8
    if venus.get('dignity') in ['入庙', '旺相']:
        scores['career'] += 15; notes['career'].append(f"金星{venus['dignity']}(财缘佳)")
    elif venus.get('dignity') in ['落陷', '失势']:
        scores['career'] -= 5
    else:
        scores['career'] += 6
    if sun.get('house') == 10:
        scores['career'] += 20; notes['career'].append("太阳10宫(事业显赫)")
    elif sun.get('house') in [2, 6]:
        scores['career'] += 10
    if jupiter.get('house') in [2, 10]:
        scores['career'] += 15; notes['career'].append(f"木星{jupiter['house']}宫(财运宫)")
    if saturn.get('dignity') in ['入庙', '旺相']:
        scores['career'] += 15; notes['career'].append(f"土星{saturn['dignity']}(根基稳)")
    elif saturn.get('dignity') in ['落陷', '失势']:
        scores['career'] -= 5
    for a in aspects:
        if {'Sun', 'Jupiter'} == {a['p1'], a['p2']}:
            if a['angle'] == 120:
                scores['career'] += 18; notes['career'].append("日木三分(大吉)")
            elif a['angle'] == 0:
                scores['career'] += 10

    # 健康
    moon = pm.get('Moon', {})
    if sun.get('dignity') in ['入庙', '旺相']:
        scores['health'] += 20; notes['health'].append(f"太阳{sun['dignity']}(生命力旺)")
    elif sun.get('dignity') in ['落陷', '失势']:
        scores['health'] -= 8; notes['health'].append(f"太阳{sun['dignity']}")
    else:
        scores['health'] += 8
    if moon.get('dignity') in ['入庙', '旺相']:
        scores['health'] += 20; notes['health'].append(f"月亮{moon['dignity']}(情绪稳)")
    elif moon.get('dignity') in ['落陷', '失势']:
        scores['health'] -= 8; notes['health'].append(f"月亮{moon['dignity']}")
    else:
        scores['health'] += 8
    for a in aspects:
        if {'Sun', 'Moon'} == {a['p1'], a['p2']}:
            if a['angle'] in [120, 60]:
                scores['health'] += 18; notes['health'].append(f"日月{a['aspect']}(身心和谐)")
            elif a['angle'] == 90:
                scores['health'] -= 8; notes['health'].append(f"日月{a['aspect']}(内在张力)")
        if {'Mars', 'Saturn'} == {a['p1'], a['p2']} and a['angle'] in [90, 180]:
            scores['health'] -= 8; notes['health'].append(f"火土{a['aspect']}(体力消耗)")

    # 性格相位
    trine = len([a for a in aspects if a['angle'] == 120])
    sextile = len([a for a in aspects if a['angle'] == 60])
    square = len([a for a in aspects if a['angle'] == 90])
    opp = len([a for a in aspects if a['angle'] == 180])
    personality = trine * 5 + sextile * 3 - square * 2 - opp * 1

    western_total = scores['study'] + scores['career'] + scores['health'] + personality

    sun_dig = sun.get('dignity', '')
    moon_dig = moon.get('dignity', '')
    sun_bad = sun_dig in ['落陷', '失势']
    moon_bad = moon_dig in ['落陷', '失势']

    return {
        'sun_sign': sun.get('sign', ''), 'moon_sign': moon.get('sign', ''),
        'asc_sign': ZODIAC_SIGNS[asc_sign_idx],
        'sun_dignity': sun_dig, 'moon_dignity': moon_dig,
        'sun_house': sun.get('house', 0), 'moon_house': moon.get('house', 0),
        'mercury_dignity': m_dig, 'jupiter_dignity': jupiter.get('dignity', ''),
        'venus_dignity': venus.get('dignity', ''), 'saturn_dignity': saturn.get('dignity', ''),
        'sun_moon_both_bad': sun_bad and moon_bad,
        'scores': scores, 'personality': personality,
        'western_total': western_total,
        'aspect_summary': {'trine': trine, 'sextile': sextile, 'square': square, 'opp': opp},
        'notes': notes, 'planets': planet_info,
    }


def main():
    if len(sys.argv) < 2:
        print("用法: python natal_chart.py <inputJson> [latitude] [longitude] [tz_offset]")
        print("示例: python natal_chart.py search-top.json 39.9042 116.4074 8")
        sys.exit(1)

    input_path = sys.argv[1]
    latitude = float(sys.argv[2]) if len(sys.argv) > 2 else 39.9042
    longitude = float(sys.argv[3]) if len(sys.argv) > 3 else 116.4074
    tz_offset = int(sys.argv[4]) if len(sys.argv) > 4 else 8

    with open(input_path, 'r', encoding='utf-8') as f:
        candidates = json.load(f)

    print(f"读取 {len(candidates)} 个候选 | 纬度:{latitude} 经度:{longitude} 时区:UTC+{tz_offset}\n")
    print(f"{'#':3s} {'日期':12s} {'时辰':4s} {'八字':6s} {'紫微':6s} {'太阳':6s} {'月亮':6s} {'上升':6s} {'学业':5s} {'财运':5s} {'健康':5s} {'性格':5s} {'西方':6s} {'三体系':6s}")
    print("-" * 110)

    results = []
    for i, cand in enumerate(candidates):
        western = analyze_western(cand['python_date'], cand['python_hour'], 0,
                                  latitude, longitude, tz_offset)
        bazi_norm = cand['baziScore']
        ziwei_norm = max(0, min(100, cand['ziweiScore'] + 20))
        western_norm = max(0, min(100, western['western_total'] + 50))
        triple_score = bazi_norm * 0.3 + ziwei_norm * 0.4 + western_norm * 0.3

        result = {**cand, 'western': western,
                  'bazi_norm': round(bazi_norm, 1), 'ziwei_norm': round(ziwei_norm, 1),
                  'western_norm': round(western_norm, 1), 'triple_score': round(triple_score, 1)}
        results.append(result)

        print(f"{i+1:3d} {cand['date']:12s} {cand['hourBranch']:4s} "
              f"{cand['baziScore']:6.1f} {cand['ziweiScore']:6.1f} "
              f"{western['sun_sign']:6s} {western['moon_sign']:6s} {western['asc_sign']:6s} "
              f"{western['scores']['study']:+5d} {western['scores']['career']:+5d} {western['scores']['health']:+5d} "
              f"{western['personality']:+5d} {western['western_total']:+6d} {triple_score:6.1f}")

    results.sort(key=lambda x: x['triple_score'], reverse=True)

    print(f"\n{'='*110}")
    print(f"三体系综合排名 Top 20（八字30% + 紫微40% + 西方30%）")
    print(f"{'='*110}\n")

    for i, r in enumerate(results[:20]):
        w = r['western']
        print(f"第{i+1}名：{r['date']} {r['hourBranch']}时({r['timeRange']}) | 三体系:{r['triple_score']} "
              f"(八字{r['bazi_norm']} 紫微{r['ziwei_norm']} 西方{r['western_norm']})")
        print(f"  八字: {r['bazi']}")
        lz = r['lzPalace'] + '[' + r['lzBright'] + ']' if r['lzMutagen'] == '忌' else '无'
        print(f"  紫微: 命宫{r['mingMain']} {r['mingLucky'] and '★'+r['mingLucky'] or ''} [{r['changsheng']}] | "
              f"福德{r['fudeMain']} | 化忌:{lz}")
        print(f"  西方: 日{w['sun_sign']}[{w['sun_dignity']}] 月{w['moon_sign']}[{w['moon_dignity']}] 上升{w['asc_sign']} | "
              f"学业{w['scores']['study']:+d} 财运{w['scores']['career']:+d} 健康{w['scores']['health']:+d}")
        if w['sun_moon_both_bad']:
            print(f"  ⚠ 日月均落陷")
        print()

    output_path = os.path.join(SCRIPT_DIR, 'search-triple.json')
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(results[:20], f, ensure_ascii=False, indent=2, default=str)
    print(f"Top 20 三体系结果已保存到 {output_path}")


if __name__ == '__main__':
    main()
