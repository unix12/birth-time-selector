#!/usr/bin/env node
/**
 * 全量三体系搜索（八字 + 紫微斗数）
 *
 * 用法：
 *   node search-full.js <startDate> <endDate> <gender> [topN]
 *   node search-full.js 2026-10-08 2026-11-05 女 40
 *
 * 输出：search-top.json（Top N 候选，供 natal_chart.py 使用）
 */
const { astro } = require('iztro');
const { Solar } = require('lunar-typescript');
const fs = require('fs');
const path = require('path');

// ==================== 常量 ====================
const BRANCHES = ['子','丑','寅','卯','辰','巳','午','未','申','酉','戌','亥'];
const STEMS = ['甲','乙','丙','丁','戊','己','庚','辛','壬','癸'];
const ELEMENTS = { '甲':'木','乙':'木','丙':'火','丁':'火','戊':'土','己':'土','庚':'金','辛':'金','壬':'水','癸':'水' };
const BRANCH_ELEM = { '子':'水','丑':'土','寅':'木','卯':'木','辰':'土','巳':'火','午':'火','未':'土','申':'金','酉':'金','戌':'土','亥':'水' };
const BRANCH_TO_TI = { '子':0,'丑':1,'寅':2,'卯':3,'辰':4,'巳':5,'午':6,'未':7,'申':8,'酉':9,'戌':10,'亥':11 };
const BRANCH_HOURS = { '子':0,'丑':2,'寅':4,'卯':6,'辰':8,'巳':10,'午':12,'未':14,'申':16,'酉':18,'戌':20,'亥':22 };
const MAIN_STARS = ['紫微','天机','太阳','武曲','天同','廉贞','天府','贪狼','巨门','太阴','天相','天梁','七杀','破军'];
const LUCKY_STARS = ['左辅','右弼','天魁','天钺','文昌','文曲','禄存','天马'];
const UNLUCKY_STARS = ['擎羊','陀罗','火星','铃星','地空','地劫'];
const GOOD_BRIGHT = ['庙','旺','得地','得'];
const BAD_BRIGHT = ['陷','闲'];
const BENEFICIAL = { '田宅':1, '官禄':1, '福德':1, '父母':1 };

// ==================== 五鼠遁（已修复） ====================
function getHourStem(dayStem, hourBranch) {
  const rules = {
    '甲':['甲','乙','丙','丁','戊','己','庚','辛','壬','癸','甲','乙'],
    '己':['甲','乙','丙','丁','戊','己','庚','辛','壬','癸','甲','乙'],
    '乙':['丙','丁','戊','己','庚','辛','壬','癸','甲','乙','丙','丁'],
    '庚':['丙','丁','戊','己','庚','辛','壬','癸','甲','乙','丙','丁'],
    '丙':['戊','己','庚','辛','壬','癸','甲','乙','丙','丁','戊','己'],
    '辛':['戊','己','庚','辛','壬','癸','甲','乙','丙','丁','戊','己'],
    '丁':['庚','辛','壬','癸','甲','乙','丙','丁','戊','己','庚','辛'],
    '壬':['庚','辛','壬','癸','甲','乙','丙','丁','戊','己','庚','辛'],
    '戊':['壬','癸','甲','乙','丙','丁','戊','己','庚','辛','壬','癸'],
    '癸':['壬','癸','甲','乙','丙','丁','戊','己','庚','辛','壬','癸'],
  };
  return rules[dayStem][BRANCHES.indexOf(hourBranch)];
}

// ==================== 八字评分 ====================
function countElements(bazi) {
  const c = {木:0,火:0,土:0,金:0,水:0};
  for (const p of bazi) { c[ELEMENTS[p[0]]]++; c[BRANCH_ELEM[p[1]]]++; }
  return c;
}

function checkBranchRelations(branches) {
  const issues = [];
  const clash = [['子','午'],['丑','未'],['寅','申'],['卯','酉'],['辰','戌'],['巳','亥']];
  const harm = [['子','未'],['丑','午'],['寅','巳'],['卯','辰'],['申','亥'],['酉','戌']];
  for (let i = 0; i < branches.length; i++)
    for (let j = i+1; j < branches.length; j++) {
      const pair = [branches[i],branches[j]].sort();
      if (clash.some(c => c[0]===pair[0]&&c[1]===pair[1])) issues.push(`${branches[i]}${branches[j]}冲`);
      if (harm.some(c => c[0]===pair[0]&&c[1]===pair[1])) issues.push(`${branches[i]}${branches[j]}害`);
    }
  return issues;
}

function scoreBazi(bazi) {
  let score = 50;
  const counts = countElements(bazi);
  const elems = Object.values(counts);
  const max = Math.max(...elems), min = Math.min(...elems);
  if (min >= 1) score += 12;
  if (max - min <= 3) score += 10; else if (max - min <= 4) score += 6;
  if (elems.every(e => e >= 1)) score += 8;
  const dayStem = bazi[2][0], dayElem = ELEMENTS[dayStem];
  const dayBranch = bazi[2][1], monthBranch = bazi[1][1], monthElem = BRANCH_ELEM[monthBranch];
  let strength = 0;
  if (monthElem === dayElem || (monthElem==='土'&&(dayElem==='火'||dayElem==='土'))) strength += 2;
  if (BRANCH_ELEM[dayBranch] === dayElem) strength += 1;
  if (BRANCH_ELEM[bazi[3][1]] === dayElem) strength += 1;
  const gen = {'木':['水'],'火':['木'],'土':['火'],'金':['土'],'水':['金']};
  if (gen[dayElem].includes(monthElem)) strength += 1;
  if (counts[gen[dayElem][0]] >= 2) strength += 1;
  if (strength >= 3 && strength <= 5) score += 15;
  else if (strength >= 2 && strength <= 6) score += 10;
  else if (strength < 2) score += 5;
  const branches = [bazi[0][1], bazi[1][1], bazi[2][1], bazi[3][1]];
  const issues = checkBranchRelations(branches);
  if (issues.length === 0) score += 12; else score -= issues.length * 5;
  const combine = [['子','丑'],['寅','亥'],['卯','戌'],['辰','酉'],['巳','申'],['午','未']];
  for (let i = 0; i < branches.length; i++)
    for (let j = i+1; j < branches.length; j++) {
      const pair = [branches[i],branches[j]].sort();
      if (combine.some(c => c[0]===pair[0]&&c[1]===pair[1])) score += 4;
    }
  const yearElem = ELEMENTS[bazi[0][0]];
  if (gen[yearElem] && gen[yearElem].includes(dayElem)) score += 3;
  return Math.min(score, 100);
}

// ==================== 紫微评分 ====================
function evalMing(p) {
  if (!p) return 0;
  let s = 0;
  const main = (p.majorStars||[]).filter(x => x.name && MAIN_STARS.includes(x.name));
  const minor = (p.minorStars||[]).filter(x => x.name);
  const lucky = minor.filter(x => LUCKY_STARS.includes(x.name));
  const unlucky = minor.filter(x => UNLUCKY_STARS.includes(x.name));
  for (const st of main) {
    const b = st.brightness || '';
    if (['紫微','天府','太阳','太阴'].includes(st.name)) {
      if (GOOD_BRIGHT.includes(b)) s += 8; else if (BAD_BRIGHT.includes(b)) s -= 3; else s += 4;
    } else if (['天相','天梁','天同'].includes(st.name)) {
      if (GOOD_BRIGHT.includes(b)) s += 6; else if (BAD_BRIGHT.includes(b)) s -= 2; else s += 3;
    } else {
      if (GOOD_BRIGHT.includes(b)) s += 4; else if (BAD_BRIGHT.includes(b)) s -= 4; else s += 1;
    }
    if (st.mutagen === '科') s += 5;
    if (st.mutagen === '禄') s += 5;
    if (st.mutagen === '权') s += 3;
  }
  if (main.length === 0) s -= 2;
  for (const st of lucky) {
    if (['左辅','右弼','天魁','天钺'].includes(st.name)) s += 4;
    else if (['文昌','文曲'].includes(st.name)) s += 4;
    else if (st.name === '禄存') s += 5;
  }
  for (const st of unlucky) {
    if (['地空','地劫'].includes(st.name)) s -= 4; else s -= 2;
  }
  const cs = p.changsheng12 || '';
  if (['长生','帝旺','临官','冠带'].includes(cs)) s += 4;
  if (['死','墓','绝'].includes(cs)) s -= 2;
  return s;
}

const FUDE_GOOD = {'天同':8,'天梁':8,'紫微':7,'天府':8,'太阴':7,'太阳':6,'天相':7,'武曲':3};
const FUDE_BAD = {'七杀':-4,'破军':-4,'贪狼':-3,'巨门':-3};

function evalFude(p) {
  if (!p) return 0;
  let s = 0;
  const main = (p.majorStars||[]).filter(x => x.name && MAIN_STARS.includes(x.name));
  const minor = (p.minorStars||[]).filter(x => x.name);
  const lucky = minor.filter(x => LUCKY_STARS.includes(x.name));
  const unlucky = minor.filter(x => UNLUCKY_STARS.includes(x.name));
  if (main.length === 0) s += 2;
  for (const st of main) {
    const b = st.brightness || '';
    let base = FUDE_GOOD[st.name] || FUDE_BAD[st.name] || 0;
    if (st.name === '廉贞' && st.mutagen === '忌') base = 4;
    if (GOOD_BRIGHT.includes(b)) base = Math.abs(base) > 0 ? Math.abs(base) : 3;
    if (BAD_BRIGHT.includes(b)) base = base > 0 ? -Math.abs(base)/2 : base;
    s += base;
    if (st.mutagen && st.mutagen !== '忌') s += 4;
  }
  for (const st of lucky) {
    if (['左辅','右弼','天魁','天钺'].includes(st.name)) s += 4;
    else if (['文昌','文曲'].includes(st.name)) s += 3;
    else if (st.name === '禄存') s += 5;
    else if (st.name === '天马') s += 1;
  }
  for (const st of unlucky) {
    if (['地空','地劫'].includes(st.name)) s -= 5;
    else if (['擎羊','陀罗'].includes(st.name)) s -= 3;
    else s -= 2;
  }
  return s;
}

function evalGuanlu(p) {
  if (!p) return 0;
  let s = 0;
  const main = (p.majorStars||[]).filter(x => x.name && MAIN_STARS.includes(x.name));
  const lucky = (p.minorStars||[]).filter(x => LUCKY_STARS.includes(x.name));
  const unlucky = (p.minorStars||[]).filter(x => UNLUCKY_STARS.includes(x.name));
  for (const st of main) {
    if (GOOD_BRIGHT.includes(st.brightness)) s += 4;
    if (BAD_BRIGHT.includes(st.brightness)) s -= 2;
    if (st.mutagen === '禄' || st.mutagen === '权') s += 4;
  }
  s += lucky.length * 2 - unlucky.length * 1;
  return s;
}

function evalCaibo(p) {
  if (!p) return 0;
  let s = 0;
  const main = (p.majorStars||[]).filter(x => x.name && MAIN_STARS.includes(x.name));
  const lucky = (p.minorStars||[]).filter(x => LUCKY_STARS.includes(x.name));
  for (const st of main) {
    if (['天府','武曲','太阴','禄存'].includes(st.name) && GOOD_BRIGHT.includes(st.brightness)) s += 5;
    if (st.mutagen === '禄') s += 5;
  }
  s += lucky.filter(x => x.name === '禄存' || x.name === '天马').length * 3;
  return s;
}

function getTimeRange(b) {
  return {'子':'23:00-01:00','丑':'01:00-03:00','寅':'03:00-05:00','卯':'05:00-07:00',
    '辰':'07:00-09:00','巳':'09:00-11:00','午':'11:00-13:00','未':'13:00-15:00',
    '申':'15:00-17:00','酉':'17:00-19:00','戌':'19:00-21:00','亥':'21:00-23:00'}[b] || '';
}

// ==================== 主搜索 ====================
function main() {
  const args = process.argv.slice(2);
  if (args.length < 3) {
    console.log('用法: node search-full.js <startDate> <endDate> <gender> [topN]');
    console.log('示例: node search-full.js 2026-10-08 2026-11-05 女 40');
    process.exit(1);
  }
  const [startStr, endStr, gender, topNStr] = args;
  const topN = parseInt(topNStr) || 40;
  const startDate = new Date(startStr);
  const endDate = new Date(endStr);

  if (isNaN(startDate) || isNaN(endDate)) {
    console.error('日期格式错误，请使用 YYYY-MM-DD');
    process.exit(1);
  }

  const results = [];
  let total = 0, errors = 0;

  for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
    const y = d.getFullYear(), m = d.getMonth() + 1, day = d.getDate();
    const dateStr = `${y}-${m}-${day}`;
    const solar = Solar.fromYmd(y, m, day);
    const lunar = solar.getLunar();
    const yP = lunar.getYearInGanZhiExact();
    const mP = lunar.getMonthInGanZhiExact();
    const dP = lunar.getDayInGanZhiExact();
    const dStem = dP[0];

    for (const hb of BRANCHES) {
      total++;
      const hStem = getHourStem(dStem, hb);
      const hP = hStem + hb;
      const bazi = [yP, mP, dP, hP];
      const baziScore = scoreBazi(bazi);

      const ti = BRANCH_TO_TI[hb];
      let astrolabe;
      try { astrolabe = astro.astrolabeBySolarDate(dateStr, ti, gender, true, 'zh-CN'); }
      catch(e) { errors++; continue; }

      const palaces = astrolabe.palaces;
      if (!palaces) { errors++; continue; }

      let lzPal='', lzBri='', lzMut='';
      let tyPal='', tyBri='', tyiPal='', tyiBri='';
      for (const p of palaces) {
        const all = [...(p.majorStars||[]), ...(p.minorStars||[])];
        for (const s of all) {
          if (s.name === '廉贞') { lzPal=p.name; lzBri=s.brightness||''; lzMut=s.mutagen||''; }
          if (s.name === '太阳') { tyPal=p.name; tyBri=s.brightness||''; }
          if (s.name === '太阴') { tyiPal=p.name; tyiBri=s.brightness||''; }
        }
      }

      const ming = palaces.find(p => p.name === '命宫');
      const fude = palaces.find(p => p.name === '福德');
      const guanlu = palaces.find(p => p.name === '官禄');
      const caibo = palaces.find(p => p.name === '财帛');

      const mingScore = evalMing(ming);
      const fudeScore = evalFude(fude);
      const guanluScore = evalGuanlu(guanlu);
      const caiboScore = evalCaibo(caibo);

      let smScore = 0;
      if (GOOD_BRIGHT.includes(tyBri)) smScore += 5; else if (BAD_BRIGHT.includes(tyBri)) smScore -= 4;
      if (GOOD_BRIGHT.includes(tyiBri)) smScore += 5; else if (BAD_BRIGHT.includes(tyiBri)) smScore -= 4;

      let hjScore = 0;
      if (lzMut === '忌') {
        if (BENEFICIAL[lzPal]) hjScore += 12;
        else if (lzPal === '命宫' || lzPal === '身宫') hjScore -= 8;
        else if (lzPal === '夫妻' || lzPal === '疾厄') hjScore -= 5;
        else hjScore += 2;
        if (GOOD_BRIGHT.includes(lzBri)) hjScore += 3;
        if (BAD_BRIGHT.includes(lzBri)) hjScore -= 3;
      }

      let dyScore = 0;
      try {
        const h = astrolabe.horoscope();
        if (h && h.decadal && typeof h.decadal.index === 'number' && h.decadal.index >= 0) {
          const palIdx = h.decadal.index;
          if (palIdx < palaces.length) {
            const dp = palaces[palIdx];
            if (dp) {
              const dLucky = (dp.minorStars||[]).filter(s => LUCKY_STARS.includes(s.name)).length;
              const dUnlucky = (dp.minorStars||[]).filter(s => UNLUCKY_STARS.includes(s.name)).length;
              dyScore += dLucky * 2 - dUnlucky * 2;
            }
          }
        }
      } catch(e) {}

      const ziweiScore = mingScore * 1.5 + fudeScore * 1.2 + guanluScore + caiboScore + smScore + hjScore + dyScore;
      const totalScore = baziScore * 0.35 + ziweiScore * 0.65;

      const weekday = '日一二三四五六'[d.getDay()];
      const mingMain = (ming?.majorStars||[]).filter(s=>s.name&&MAIN_STARS.includes(s.name)).map(s=>`${s.name}[${s.brightness||''}]${s.mutagen?'化'+s.mutagen:''}`).join('·') || '空宫';
      const mingLucky = (ming?.minorStars||[]).filter(s=>s.name&&LUCKY_STARS.includes(s.name)).map(s=>s.name).join(',');
      const fudeMain = (fude?.majorStars||[]).filter(s=>s.name&&MAIN_STARS.includes(s.name)).map(s=>`${s.name}[${s.brightness||''}]${s.mutagen?'化'+s.mutagen:''}`).join('·') || '空宫';
      const fudeLucky = (fude?.minorStars||[]).filter(s=>s.name&&LUCKY_STARS.includes(s.name)).map(s=>s.name).join(',');

      results.push({
        date: `${m}月${day}日(${weekday})`,
        dateISO: `${y}-${String(m).padStart(2,'0')}-${String(day).padStart(2,'0')}`,
        weekday, hourBranch: hb, hourNum: BRANCH_HOURS[hb],
        timeRange: getTimeRange(hb), timeIndex: ti,
        bazi: bazi.join(' '), baziScore,
        ziweiScore: Math.round(ziweiScore * 10) / 10,
        mingScore: Math.round(mingScore * 10) / 10,
        fudeScore: Math.round(fudeScore * 10) / 10,
        guanluScore: Math.round(guanluScore * 10) / 10,
        caiboScore: Math.round(caiboScore * 10) / 10,
        sunMoonScore: smScore, huaJiScore: hjScore, dayunScore: dyScore,
        totalScore: Math.round(totalScore * 10) / 10,
        lzPalace: lzPal, lzBright: lzBri, lzMutagen: lzMut,
        tyPalace: tyPal, tyBright: tyBri,
        tyiPalace: tyiPal, tyiBright: tyiBri,
        mingMain, mingLucky, fudeMain, fudeLucky,
        changsheng: ming?.changsheng12 || '',
        fiveElements: astrolabe.fiveElementsClass,
        python_date: `${y}-${String(m).padStart(2,'0')}-${String(day).padStart(2,'0')}`,
        python_hour: BRANCH_HOURS[hb],
      });
    }
  }

  results.sort((a, b) => b.totalScore - a.totalScore);
  const top = results.slice(0, topN);

  console.log(`\n${'═'.repeat(90)}`);
  console.log(`  全量搜索：${startStr} ~ ${endStr} | ${gender} | 全部${total}组日时（错误${errors}组）`);
  console.log(`  八字(35%)+紫微(65%)综合评分，输出Top ${top.length}`);
  console.log(`${'═'.repeat(90)}\n`);

  top.forEach((r, i) => {
    console.log(`${String(i+1).padStart(2)}. ${r.date} ${r.hourBranch}时(${r.timeRange}) | 综合:${r.totalScore} 八字:${r.baziScore} 紫微:${r.ziweiScore}`);
    console.log(`    八字: ${r.bazi}`);
    console.log(`    命宫: ${r.mingMain} ${r.mingLucky?'★'+r.mingLucky:''} [${r.changsheng}] | 命分:${r.mingScore}`);
    console.log(`    福德: ${r.fudeMain} ${r.fudeLucky?'★'+r.fudeLucky:''} | 福德分:${r.fudeScore}`);
    console.log(`    化忌: ${r.lzMutagen==='忌'?r.lzPalace+'['+r.lzBright+']':'无'} | 日:${r.tyPalace}[${r.tyBright}] 月:${r.tyiPalace}[${r.tyiBright}]`);
    console.log('');
  });

  const outPath = path.join(__dirname, 'search-top.json');
  fs.writeFileSync(outPath, JSON.stringify(top, null, 2), 'utf-8');
  console.log(`Top ${top.length} JSON已保存到 ${outPath}`);

  console.log(`\n--- 统计 ---`);
  console.log(`化忌在有利宫位: ${results.filter(r=>r.lzMutagen==='忌'&&BENEFICIAL[r.lzPalace]).length}组`);
  console.log(`日月均庙旺: ${results.filter(r=>GOOD_BRIGHT.includes(r.tyBright)&&GOOD_BRIGHT.includes(r.tyiBright)).length}组`);
  console.log(`福德分>=10: ${results.filter(r=>r.fudeScore>=10).length}组`);
  console.log(`命分>=10: ${results.filter(r=>r.mingScore>=10).length}组`);
}

main();
